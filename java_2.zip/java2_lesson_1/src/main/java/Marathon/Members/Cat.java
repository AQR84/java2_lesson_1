package Marathon.Members;

import Marathon.Members.Animal;

public class Cat extends Animal {
    public Cat(String name) {
        super("Кот", name, 200, 20, 0);
    }
}
