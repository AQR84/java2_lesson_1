package Marathon.obstacles;

import Marathon.Members.Interfaces.Competitor;

public abstract class Obstacle {
    public abstract void doIt(Competitor competitor);
}